import { useMemo, useRef, useCallback } from 'react';
import { format, addMonths, getDay } from 'date-fns';
import { motion, useMotionValue, animate } from 'motion/react';
import { useCalendarDataStore } from './calendarDataStore';
import { useCalendarNavStore } from './calendarNavStore';
import {
  generateMonthGrid,
  isCurrentMonth,
  isSameDay,
  isToday,
  formatEventTime,
  getEventsForDate,
  dateKey,
  getChineseHolidays,
  getHolidayEventsForYear,
  WEEKDAY_HEADERS,
} from './calendarUtils';

const SWIPE_THRESHOLD = 50;
const GRID_HEIGHT = 6 * 48 + 12;

/** Build a map of dateKey → color[] for multi-color dots */
function buildColorDotsMap(
  events: { startTime: number; endTime: number; color: string; isAllDay: boolean }[],
  holidays: Map<string, string>,
): Map<string, string[]> {
  const map = new Map<string, Set<string>>();

  for (const event of events) {
    const start = new Date(event.startTime);
    const end = new Date(event.endTime);
    let current = new Date(start.getFullYear(), start.getMonth(), start.getDate());
    const endDay = new Date(end.getFullYear(), end.getMonth(), end.getDate());
    while (current <= endDay) {
      const key = format(current, 'yyyy-MM-dd');
      if (!map.has(key)) map.set(key, new Set());
      map.get(key)!.add(event.color);
      current = new Date(current.getTime() + 86400000);
    }
  }

  // Holiday events get systemRed
  for (const key of holidays.keys()) {
    if (!map.has(key)) map.set(key, new Set());
    map.get(key)!.add('var(--color-systemRed)');
  }

  const result = new Map<string, string[]>();
  for (const [key, colors] of map) {
    result.set(key, Array.from(colors).slice(0, 3));
  }
  return result;
}

export function MonthView() {
  const events = useCalendarDataStore((s) => s.events);
  const selectedDate = useCalendarDataStore((s) => s.selectedDate);
  const currentMonth = useCalendarDataStore((s) => s.currentMonth);
  const setSelectedDate = useCalendarDataStore((s) => s.setSelectedDate);
  const setCurrentMonth = useCalendarDataStore((s) => s.setCurrentMonth);
  const push = useCalendarNavStore((s) => s.push);

  const grid = useMemo(() => generateMonthGrid(currentMonth), [currentMonth]);

  const prevMonthTs = useMemo(() => addMonths(currentMonth, -1).getTime(), [currentMonth]);
  const nextMonthTs = useMemo(() => addMonths(currentMonth, 1).getTime(), [currentMonth]);
  const prevGrid = useMemo(() => generateMonthGrid(prevMonthTs), [prevMonthTs]);
  const nextGrid = useMemo(() => generateMonthGrid(nextMonthTs), [nextMonthTs]);

  const holidays = useMemo(() => {
    const year = new Date(currentMonth).getFullYear();
    const map = new Map<string, string>();
    for (const y of [year - 1, year, year + 1]) {
      for (const [k, v] of getChineseHolidays(y)) {
        map.set(k, v);
      }
    }
    return map;
  }, [currentMonth]);

  const colorDots = useMemo(
    () => buildColorDotsMap(events, holidays),
    [events, holidays],
  );

  const allEventsWithHolidays = useMemo(() => {
    const year = new Date(selectedDate).getFullYear();
    return [...events, ...getHolidayEventsForYear(year)];
  }, [events, selectedDate]);

  const dayEvents = useMemo(
    () => getEventsForDate(allEventsWithHolidays, selectedDate),
    [allEventsWithHolidays, selectedDate],
  );

  // ── Swipe gesture state (refs, not React state — 60fps) ──
  const dragY = useMotionValue(0);
  const isDraggingRef = useRef(false);
  const isAnimatingRef = useRef(false);
  const touchStartYRef = useRef(0);

  const navigateMonth = useCallback(
    (delta: number) => {
      setCurrentMonth(addMonths(currentMonth, delta).getTime());
    },
    [currentMonth, setCurrentMonth],
  );

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (isAnimatingRef.current) return;
    touchStartYRef.current = e.touches[0]!.clientY;
    isDraggingRef.current = true;
    dragY.stop();
  }, [dragY]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isDraggingRef.current) return;
    const dy = e.touches[0]!.clientY - touchStartYRef.current;
    dragY.set(dy);
  }, [dragY]);

  const handleTouchEnd = useCallback(() => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;
    const dy = dragY.get();
    const vel = dragY.getVelocity();

    const pastThreshold = Math.abs(dy) > SWIPE_THRESHOLD;
    const fastSwipe = Math.abs(vel) > 300;

    if (pastThreshold || fastSwipe) {
      const dir = pastThreshold
        ? (dy < 0 ? 1 : -1)
        : (vel < 0 ? 1 : -1);
      isAnimatingRef.current = true;
      animate(dragY, -dir * GRID_HEIGHT, {
        duration: 0.25,
        ease: [0.2, 0, 0, 1],
        onComplete: () => {
          dragY.jump(0);
          navigateMonth(dir);
          isAnimatingRef.current = false;
        },
      });
    } else {
      animate(dragY, 0, { duration: 0.2, ease: [0.2, 0, 0, 1] });
    }
  }, [dragY, navigateMonth]);

  const handleDateTap = (date: Date) => {
    setSelectedDate(date.getTime());
    if (!isCurrentMonth(date, currentMonth)) {
      setCurrentMonth(date.getTime());
    }
  };

  // ── Grid renderer (shared by prev / current / next) ──
  const renderMonthGrid = useCallback(
    (dates: Date[], refMonth: number, testId?: string) => (
      <div
        className="grid"
        style={{
          gridTemplateColumns: 'repeat(7, 1fr)',
          padding: '4px 16px 8px',
          height: GRID_HEIGHT,
        }}
        data-testid={testId}
      >
        {dates.map((date) => {
          const isInMonth = isCurrentMonth(date, refMonth);

          // Out-of-month dates render as empty cells
          if (!isInMonth) {
            return <div key={date.toISOString()} style={{ height: 48 }} />;
          }

          const today = isToday(date);
          const selected = isSameDay(date, selectedDate);
          const key = dateKey(date);
          const dots = colorDots.get(key);
          const isSunday = date.getDay() === 0;

          const numberColor = today
            ? '#fff'
            : isSunday
              ? 'var(--color-systemRed)'
              : 'var(--color-label)';

          return (
            <button
              key={date.toISOString()}
              type="button"
              onClick={() => handleDateTap(date)}
              className="flex flex-col items-center justify-center"
              style={{ height: 48, position: 'relative' }}
              data-testid={`date-${format(date, 'yyyy-MM-dd')}`}
            >
              <div
                className="flex items-center justify-center"
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: '50%',
                  backgroundColor: today
                    ? 'var(--color-systemRed)'
                    : selected && !today
                      ? 'rgba(0,0,0,0.04)'
                      : 'transparent',
                }}
              >
                <span
                  style={{
                    fontSize: 17,
                    fontWeight: today ? 600 : selected ? 500 : 400,
                    color: numberColor,
                    letterSpacing: -0.2,
                  }}
                >
                  {format(date, 'd')}
                </span>
              </div>

              {/* Holiday "休" label */}
              {holidays.has(key) && (
                <span
                  style={{
                    position: 'absolute',
                    top: 2,
                    right: 4,
                    fontSize: 7,
                    fontWeight: 700,
                    color: 'rgba(52,199,89,0.7)',
                    lineHeight: 1,
                  }}
                >
                  休
                </span>
              )}

              {/* Multi-color event dots */}
              {dots && !today && (
                <div
                  className="flex"
                  style={{ gap: 3, height: 4, marginTop: 2 }}
                >
                  {dots.map((c, i) => (
                    <div
                      key={i}
                      style={{
                        width: 4,
                        height: 4,
                        borderRadius: '50%',
                        backgroundColor: c,
                      }}
                    />
                  ))}
                </div>
              )}
            </button>
          );
        })}
      </div>
    ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedDate, colorDots, holidays],
  );

  const selectedWeekday = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'][
    getDay(new Date(selectedDate))
  ];
  const isTodaySelected = isToday(new Date(selectedDate));

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      {/* ── Weekday header ── */}
      <div
        className="grid"
        style={{
          gridTemplateColumns: 'repeat(7, 1fr)',
          padding: '12px 16px 6px',
        }}
      >
        {WEEKDAY_HEADERS.map((d, i) => (
          <div
            key={d}
            className="text-center"
            style={{
              fontSize: 11,
              fontWeight: 600,
              color: i === 0 ? 'rgba(255,59,48,0.35)' : 'var(--color-secondaryLabel)',
              opacity: i === 0 ? 1 : 0.5,
              lineHeight: '18px',
              textTransform: 'uppercase',
              letterSpacing: 0.2,
            }}
          >
            {d}
          </div>
        ))}
      </div>

      {/* ── Separator ── */}
      <div
        style={{
          height: 0.5,
          background: 'var(--color-separator)',
          margin: '0 20px',
        }}
      />

      {/* ── Month grid — 3 months stacked (prev / current / next) ── */}
      <div
        style={{ height: GRID_HEIGHT, overflow: 'hidden', position: 'relative' }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <motion.div
          style={{
            y: dragY,
            position: 'absolute',
            left: 0,
            right: 0,
            top: -GRID_HEIGHT,
          }}
        >
          {renderMonthGrid(prevGrid, prevMonthTs)}
          {renderMonthGrid(grid, currentMonth, 'month-grid')}
          {renderMonthGrid(nextGrid, nextMonthTs)}
        </motion.div>
      </div>

      {/* ── Lower half: event list ── */}
      <div
        className="flex flex-1 flex-col overflow-hidden"
        style={{ backgroundColor: 'var(--color-systemGroupedBackground)' }}
      >
        {/* Date label */}
        <div className="flex items-baseline" style={{ padding: '16px 20px 10px' }}>
          <span
            style={{
              fontSize: 14,
              fontWeight: 600,
              color: 'var(--color-label)',
            }}
          >
            {format(selectedDate, 'M月d日')}
          </span>
          <span
            style={{
              fontSize: 13,
              fontWeight: 400,
              color: 'var(--color-tertiaryLabel)',
              marginLeft: 6,
            }}
          >
            {selectedWeekday}
            {isTodaySelected && ' · 今天'}
          </span>
        </div>

        {/* Event list */}
        <div className="flex-1 overflow-auto" style={{ paddingBottom: 16 }}>
          {dayEvents.length === 0 ? (
            <div
              className="flex items-center justify-center"
              style={{
                height: 80,
                color: 'var(--color-secondaryLabel)',
                fontSize: 15,
                fontWeight: 500,
              }}
            >
              没有事件
            </div>
          ) : (
            dayEvents.map((event, i) => (
              <button
                key={event.id}
                type="button"
                className="flex w-full items-center"
                style={{
                  paddingLeft: 20,
                  minHeight: 44,
                  cursor: 'pointer',
                  textAlign: 'left',
                }}
                onClick={() => push('event-detail', { eventId: event.id })}
                data-testid={`event-row-${event.id}`}
              >
                {/* Color dot icon */}
                <div
                  style={{
                    width: 10,
                    height: 10,
                    borderRadius: '50%',
                    backgroundColor: event.color,
                    flexShrink: 0,
                    marginRight: 10,
                  }}
                />
                {/* Title + time, separator extends to right edge */}
                <div
                  className="flex min-w-0 flex-1 items-center"
                  style={{
                    padding: '12px 20px 12px 0',
                    borderBottom:
                      i < dayEvents.length - 1
                        ? '0.5px solid var(--color-separator)'
                        : 'none',
                  }}
                >
                  <span
                    className="truncate"
                    style={{
                      fontSize: 15,
                      fontWeight: 400,
                      color: 'var(--color-label)',
                      flex: 1,
                    }}
                  >
                    {event.title}
                  </span>
                  <span
                    style={{
                      fontSize: 14,
                      color: 'var(--color-secondaryLabel)',
                      flexShrink: 0,
                      marginLeft: 12,
                    }}
                  >
                    {formatEventTime(event.startTime, event.endTime, event.isAllDay)}
                  </span>
                </div>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
